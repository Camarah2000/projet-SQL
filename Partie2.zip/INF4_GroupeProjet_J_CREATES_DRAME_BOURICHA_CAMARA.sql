
-----Q2 et Q4----------

----Suppression----
DROP VIEW IF EXISTS materiel;
DROP VIEW IF EXISTS employe;


DROP TABLE IF EXISTS indisponibilite;
DROP TABLE IF EXISTS reservation;
DROP TABLE IF EXISTS exemplaire;
DROP TABLE IF EXISTS employe_base;
DROP TABLE IF EXISTS materiel_base;
DROP TABLE IF EXISTS categorie;



-----Creation table et View------

CREATE TABLE categorie (
	id_categorie INTEGER,
	libelle_categorie TEXT UNIQUE NOT NULL,
	nbEmpruntsMax_categorie INTEGER NOT NULL,
	id_categorieParent INTEGER,
	CONSTRAINT pk_cat_idCat PRIMARY KEY (id_categorie),
	CONSTRAINT fk_cat_idcatParent FOREIGN KEY(id_categorieParent) REFERENCES categorie(id_categorie)
);



CREATE TABLE materiel_base (
	id_materiel INTEGER,
	libelle_materiel TEXT NOT NULL,
	nbEmpruntsEnCours_materiel INTEGER,
	id_categorie INTEGER NOT NULL,
	CONSTRAINT pk_mat_idMat PRIMARY KEY (id_materiel),
	CONSTRAINT fk_mat_idCat FOREIGN KEY (id_categorie) REFERENCES categorie (id_categorie)
);

CREATE VIEW materiel AS
SELECT
    m.id_materiel,
    m.libelle_materiel,
    m.nbEmpruntsEnCours_materiel,
    m.id_categorie,
    c.libelle_categorie
FROM
    materiel_base m
JOIN
    categorie c ON m.id_categorie = c.id_categorie;



CREATE TABLE employe_base (
	id_employe INTEGER,
	nom_employe TEXT NOT NULL,
	mail_employe TEXT NOT NULL,
	tel_employe TEXT,
	nbEmpruntsEnCours_employe INTEGER,
	CONSTRAINT pk_emp_idEmpl PRIMARY KEY (id_employe)
);

CREATE VIEW employe AS
SELECT
    e.id_employe,
    e.nom_employe,
    e.mail_employe,
    e.tel_employe,
    e.nbEmpruntsEnCours_employe,
    COUNT(r.id_exemplaire) AS nbEmpruntsEnCours_employe
FROM
    employe e
LEFT JOIN
    Resa r ON e.id_employe = r.id_employe AND r.date_retour IS NULL
GROUP BY
    e.id_employe,
    e.nom_employe,
    e.mail_employe,
    e.tel_employe,
    e.nbEmpruntsEnCours_employe;


CREATE TABLE exemplaire   (
	id_exemplaire INTEGER,
	etat_exemplaire TEXT NOT NULL,
	id_materiel INTEGER NOT NULL,
	id_indisponibilite INTEGER,
	CONSTRAINT pk_exemp_idExemp PRIMARY KEY (id_exemplaire),
	CONSTRAINT fk_exemp_idExemp FOREIGN KEY(id_materiel) REFERENCES materiel_base(id_materiel),
	CONSTRAINT ck_exemp_etatExempl CHECK (etat_exemplaire IN ('neuf',
	'bon', 'moyen', 'defectueux'))
);



CREATE TABLE reservation (
	id_reservation INTEGER,
	dateDebut_reservation DATE NOT NULL,
	dateFin_reservation DATE NOT NULL,
	dateEmprunt_reservation DATE,
	dateRetourEffective_reservation DATE,
	id_employe INTEGER NOT NULL,
	id_exemplaire INTEGER NOT NULL,
	CONSTRAINT pk_res_idRes PRIMARY KEY (id_reservation),
	CONSTRAINT fk_res_dEmpl FOREIGN KEY(id_employe) REFERENCES employe_base(id_employe),
	CONSTRAINT fk_res_idExempl FOREIGN KEY(id_exemplaire) REFERENCES exemplaire(id_exemplaire)
);




CREATE TABLE indisponibilite (
	id_indisponibilite INTEGER,
	description_indisponibilite TEXT NOT NULL,
	CONSTRAINT pk_indisp_id_indisp PRIMARY KEY (id_indisponibilite),
	CONSTRAINT ck_indisp_id_exemp CHECK (description_indisponibilite IN ('panne', 'maintenance', 'perdu'))
	
);


	
-----Q3-------------
----Transfert------

INSERT INTO categorie (id_categorie, libelle_categorie, nbEmpruntsMax_categorie)
SELECT DISTINCT id_categorie, libelle_categorie, nb_emprunt_max
FROM Resa
WHERE id_categorie IS NOT NULL AND libelle_categorie IS NOT NULL AND nb_emprunt_max IS NOT NULL;

INSERT INTO materiel_base (id_materiel, libelle_materiel, id_categorie)
SELECT DISTINCT id_materiel,libelle_materiel,id_categorie
FROM Resa
WHERE id_materiel > 0 AND id_categorie > 0;

INSERT INTO employe_base (id_employe, nom_employe, mail_employe, tel_employe)
SELECT DISTINCT id_employe, nom_employe,mail,tel
FROM Resa
WHERE id_employe IS NOT NULL AND nom_employe IS NOT NULL AND mail IS NOT NULL AND tel IS NOT NULL ;

INSERT INTO exemplaire 
SELECT DISTINCT id_exemplaire,etat,id_materiel, id_indisponibilite
FROM Resa
WHERE id_exemplaire > 0
	AND (etat IN ('neuf', 'bon', 'moyen', 'defectueux') OR etat IS NULL)
	AND id_materiel > 0;
	
INSERT INTO reservation (dateDebut_reservation, dateFin_reservation, dateEmprunt_reservation,	dateRetourEffective_reservation,
	id_employe, id_exemplaire )

SELECT DISTINCT
    date_debut,
    date_fin,
    date_emprunt,
    date_retour,
    id_employe,
	id_exemplaire
FROM Resa
WHERE id_exemplaire IS NOT NULL
  AND id_employe IS NOT NULL
  AND date_debut IS NOT NULL
  AND date_fin IS NOT NULL;
	
INSERT INTO indisponibilite (id_indisponibilite, description_indisponibilite)
SELECT DISTINCT id_indisponibilite,description_indisponibilite
FROM Resa
WHERE id_indisponibilite IS NOT NULL
	AND description_indisponibilite IN ('panne','maintenance','perdu');


------Requettes sql------

----Q1---
SELECT DISTINCT m.id_categorie
FROM materiel_base m
JOIN exemplaire ex ON (m.id_materiel = ex.id_materiel)
JOIN reservation r ON (ex.id_exemplaire = r.id_exemplaire)
JOIN employe_base e ON (r.id_employe = e.id_employe)
WHERE e.nom_employe = 'Martin' ;


----Q2---
SELECT e.nom_employe, e.id_employe
FROM employe_base e
JOIN reservation r ON (e.id_employe = r.id_employe)
JOIN exemplaire ex ON (r.id_exemplaire = ex.id_exemplaire)
JOIN materiel_base m ON (ex.id_materiel = m.id_materiel)
WHERE m.id_materiel = 37
INTERSECT
SELECT e.nom_employe, e.id_employe
FROM employe_base e
JOIN reservation r ON (e.id_employe = r.id_employe)
JOIN exemplaire ex ON (r.id_exemplaire = ex.id_exemplaire)
JOIN materiel_base m ON (ex.id_materiel = m.id_materiel)
WHERE m.id_materiel = 38 ;


----Q3---
SELECT COUNT(DISTINCT e.id_employe) AS nb_employes
FROM employe_base e
JOIN reservation r ON e.id_employe = r.id_employe
JOIN exemplaire ex ON r.id_exemplaire = ex.id_exemplaire
JOIN materiel_base m ON ex.id_materiel = m.id_materiel
WHERE m.id_materiel = 37 OR  m.id_materiel = 38;

----Q4---
SELECT e.id_employe, e.nom_employe
FROM employe_base e
WHERE e.id_employe NOT IN (
	SELECT r.id_employe
	FROM reservation r 
) ;
	
----Q5---
SELECT r.id_employe
FROM reservation r
JOIN exemplaire ex ON (r.id_exemplaire = ex.id_exemplaire)
JOIN materiel_base m ON (ex.id_materiel = m.id_materiel)
GROUP BY r.id_employe
HAVING COUNT(DISTINCT m.id_categorie) = (
    SELECT COUNT(*) FROM categorie
);



----Q6---
SELECT m.id_materiel, m.libelle_materiel, COUNT(ex.id_exemplaire) AS nb_exemplaires 
FROM exemplaire ex
JOIN materiel_base m ON (ex.id_materiel = m.id_materiel)
GROUP BY m.id_materiel, m.libelle_materiel;


----Q7---
SELECT e.id_employe, e.nom_employe 
FROM employe_base e
JOIN reservation r ON (e.id_employe = r.id_employe)
GROUP BY e.id_employe, e.nom_employe
HAVING COUNT(r.id_reservation) >= 60;


---Q8----
SELECT e.id_employe, e.nom_employe 
FROM employe_base e
JOIN reservation r ON e.id_employe = r.id_employe
JOIN exemplaire ex ON r.id_exemplaire = ex.id_exemplaire
JOIN materiel_base m ON ex.id_materiel = m.id_materiel
WHERE m.id_materiel = 20
GROUP BY e.id_employe, e.nom_employe
HAVING COUNT(r.id_reservation) >= 2;


---Q9----

WITH duree AS (

	SELECT m.id_materiel, m.libelle_materiel, MAX((JULIANDAY(r.dateFin_reservation) - JULIANDAY( r.dateDebut_reservation))) AS dure_max_reservation
	FROM  materiel_base m
	JOIN exemplaire ex ON ex.id_materiel = m.id_materiel
	JOIN reservation r  ON r.id_exemplaire = ex.id_exemplaire
	GROUP BY  m.id_materiel, libelle_materiel
)
SELECT id_materiel, libelle_materiel
FROM duree
WHERE dure_max_reservation = 
	(SELECT  MAX(dure_max_reservation)
	 FROM duree) ;



----Q10---
WITH nombre AS(
	SELECT ex.id_exemplaire, m.libelle_materiel, COUNT(r.id_reservation) AS nb_reservation	
	FROM exemplaire ex
	JOIN reservation r ON r.id_exemplaire = ex.id_exemplaire
	JOIN materiel_base m ON ex.id_materiel = m.id_materiel
	GROUP BY ex.id_exemplaire, m.libelle_materiel
)
SELECT id_exemplaire, libelle_materiel
FROM nombre 
WHERE nb_reservation =
	(SELECT MAX(nb_reservation) 
	FROM nombre ); 



